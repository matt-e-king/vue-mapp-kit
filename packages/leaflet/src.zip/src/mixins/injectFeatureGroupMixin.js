export default {
  inject: {
    getFeatureGroup: {
      default: () => (() => (null))
    }
  }
}
