export default {
  inject: {
    getMap: {
      default: () => (() => {})
    }
  }
}
