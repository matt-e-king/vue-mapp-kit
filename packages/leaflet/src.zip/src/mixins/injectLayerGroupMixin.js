export default {
  inject: {
    getLayerGroup: {
      default: () => (() => (null))
    }
  }
}
