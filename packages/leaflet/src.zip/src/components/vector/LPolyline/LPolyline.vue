<template></template>

<script>
import constructorMixin from '@/mixins/constructorMixin'
import injectMapMixin from '@/mixins/injectMapMixin'
import injectLayerGroupMixin from '@/mixins/injectLayerGroupMixin'
import injectFeatureGroupMixin from '@/mixins/injectFeatureGroupMixin'

export default {
  name: 'LPolyline',

  mixins: [
    constructorMixin,
    injectMapMixin,
    injectLayerGroupMixin,
    injectFeatureGroupMixin
  ],

  props: {
    latlngs: {
      type: Array,
      required: true,
      default: () => ([])
    }
  },

  data() {
    return {
      moduleName: 'polyline'
    }
  },

  computed: {
    // TODO: add verification to ensure latlng type
    rootArgument () { return this.latlngs }
  }
}
</script>
